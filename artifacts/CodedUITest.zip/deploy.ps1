cd $env:APPLICATION_PATH
cmd.exe /c 'RunTests.bat'

#cd $env:APPLICATION_PATH
#$script="C:\MediaStreamer\automation\runtest.ps1"
#$pw=convertto-securestring "bluejeans" -asplaintext -force
#$pp=new-object -typename System.Management.Automation.PSCredential -argumentlist "blue",$pw
#Start-Process powershell -Credential $pp -ArgumentList '-noprofile -command &{Start-Process $script -verb runas}'
#Start-Process RunTests.bat -Credential $pp
