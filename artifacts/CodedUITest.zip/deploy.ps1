cd $env:APPLICATION_PATH
cmd.exe /c 'RunTests.bat'