ls
cmd.exe /c 'RunTests.bat'