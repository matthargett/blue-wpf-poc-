cd $env:APPLICATION_PATH
$MSTestCall = "C:\Program Files (x86)\Microsoft Visual Studio 14.0\Common7\IDE\MSTest.exe"
$PATH_TO_TESTS = $env:APPLICATION_PATH + "\AutomationTests.dll"
Write-Host 'Start UI tests: ' $PATH_TO_TESTS
$arguments = "/testcontainer:" + $PATH_TO_TESTS
& $MSTestCall $arguments

If ($? -eq $false){
Write-Host 'Test failed!'
#failure! 
#need to find way to inform team
}
Else {
Write-Host 'Test succeeded!'
}